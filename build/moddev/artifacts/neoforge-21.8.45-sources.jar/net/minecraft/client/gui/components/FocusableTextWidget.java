package net.minecraft.client.gui.components;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.narration.NarratedElementType;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.sounds.SoundManager;
import net.minecraft.network.chat.Component;
import net.minecraft.util.ARGB;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public class FocusableTextWidget extends MultiLineTextWidget {
    public static final int DEFAULT_PADDING = 4;
    private final boolean alwaysShowBorder;
    private final boolean fillBackground;
    private final int padding;

    public FocusableTextWidget(int maxWidth, Component message, Font font) {
        this(maxWidth, message, font, 4);
    }

    public FocusableTextWidget(int maxWidth, Component message, Font font, int padding) {
        this(maxWidth, message, font, true, true, padding);
    }

    public FocusableTextWidget(int maxWidth, Component message, Font font, boolean alwaysShowBorder, boolean fillBackground, int padding) {
        super(message, font);
        this.setMaxWidth(maxWidth);
        this.setCentered(true);
        this.active = true;
        this.alwaysShowBorder = alwaysShowBorder;
        this.fillBackground = fillBackground;
        this.padding = padding;
    }

    public void containWithin(int width) {
        this.setMaxWidth(width - this.padding * 4);
    }

    @Override
    protected void updateWidgetNarration(NarrationElementOutput p_295798_) {
        p_295798_.add(NarratedElementType.TITLE, this.getMessage());
    }

    @Override
    public void renderWidget(GuiGraphics p_296375_, int p_295686_, int p_295354_, float p_295563_) {
        int i = this.getX() - this.padding;
        int j = this.getY() - this.padding;
        int k = this.getWidth() + this.padding * 2;
        int l = this.getHeight() + this.padding * 2;
        int i1 = ARGB.color(this.alpha, this.alwaysShowBorder ? (this.isFocused() ? -1 : -6250336) : -1);
        if (this.fillBackground) {
            p_296375_.fill(i + 1, j, i + k, j + l, ARGB.color(this.alpha, -16777216));
        }

        if (this.isFocused() || this.alwaysShowBorder) {
            p_296375_.renderOutline(i, j, k, l, i1);
        }

        super.renderWidget(p_296375_, p_295686_, p_295354_, p_295563_);
    }

    @Override
    public void playDownSound(SoundManager p_295576_) {
    }
}
