package com.mojang.realmsclient.dto;

import com.google.gson.annotations.SerializedName;
import javax.annotation.Nullable;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;

@OnlyIn(Dist.CLIENT)
public final class RealmsSlotUpdateDto implements ReflectionBasedSerialization {
    @SerializedName("slotId")
    public final int slotId;
    @SerializedName("pvp")
    private final boolean pvp;
    @SerializedName("spawnMonsters")
    private final boolean spawnMonsters;
    @SerializedName("spawnProtection")
    private final int spawnProtection;
    @SerializedName("commandBlocks")
    private final boolean commandBlocks;
    @SerializedName("forceGameMode")
    private final boolean forceGameMode;
    @SerializedName("difficulty")
    private final int difficulty;
    @SerializedName("gameMode")
    private final int gameMode;
    @SerializedName("slotName")
    private final String slotName;
    @SerializedName("version")
    private final String version;
    @SerializedName("compatibility")
    private final RealmsServer.Compatibility compatibility;
    @SerializedName("worldTemplateId")
    private final long templateId;
    @Nullable
    @SerializedName("worldTemplateImage")
    private final String templateImage;
    @SerializedName("hardcore")
    private final boolean hardcore;

    public RealmsSlotUpdateDto(int slotId, RealmsWorldOptions options, boolean hardcore) {
        this.slotId = slotId;
        this.pvp = options.pvp;
        this.spawnMonsters = options.spawnMonsters;
        this.spawnProtection = options.spawnProtection;
        this.commandBlocks = options.commandBlocks;
        this.forceGameMode = options.forceGameMode;
        this.difficulty = options.difficulty;
        this.gameMode = options.gameMode;
        this.slotName = options.getSlotName(slotId);
        this.version = options.version;
        this.compatibility = options.compatibility;
        this.templateId = options.templateId;
        this.templateImage = options.templateImage;
        this.hardcore = hardcore;
    }
}
