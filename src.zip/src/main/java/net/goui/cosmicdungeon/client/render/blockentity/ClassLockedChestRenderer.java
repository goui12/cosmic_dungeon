package net.goui.cosmicdungeon.client.render.blockentity;

import com.mojang.blaze3d.vertex.PoseStack;
import net.goui.cosmicdungeon.CosmicDungeonMod;
import net.goui.cosmicdungeon.block.custom.ClassLocked;
import net.goui.cosmicdungeon.block.custom.ClassLockedChestBlock;
import net.goui.cosmicdungeon.block.entity.ClassLockedChestBlockEntity;
import net.goui.cosmicdungeon.client.model.ClassLockedChestModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.SubmitNodeCollector;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.blockentity.state.BlockEntityRenderState;
import net.minecraft.client.renderer.state.CameraRenderState;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.core.Direction;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;
import net.minecraft.client.renderer.feature.ModelFeatureRenderer;

import javax.annotation.Nullable;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Custom renderer for ClassLockedChestBlockEntity.
 * Uses entityCutout + direct texture files (NOT minecraft chest atlas).
 *
 * 1.21.11+ renderer pipeline:
 * - createRenderState()
 * - extractRenderState(...)
 * - submit(...)
 */
public final class ClassLockedChestRenderer implements BlockEntityRenderer<ClassLockedChestBlockEntity, ClassLockedChestRenderer.State> {

    private final ClassLockedChestModel model;

    // Cache ResourceLocations by class id so we don't allocate every frame.
    private static final Map<String, ResourceLocation> TEX_CACHE = new ConcurrentHashMap<>();

    public ClassLockedChestRenderer(BlockEntityRendererProvider.Context ctx) {
        ModelPart root = ctx.bakeLayer(ClassLockedChestModel.LAYER_LOCATION);
        this.model = new ClassLockedChestModel(root);
    }

    // ---------------------------------------------------------------------
    // Render state (1.21.11+)
    // ---------------------------------------------------------------------
    public static final class State extends BlockEntityRenderState {
        public Direction facing = Direction.NORTH;
        public float open = 0.0F;
        public ResourceLocation texture = defaultTexture();
    }

    @Override
    public State createRenderState() {
        return new State();
    }

    @Override
    public void extractRenderState(
            ClassLockedChestBlockEntity be,
            State rs,
            float partialTick,
            Vec3 cameraPosition,
            @Nullable ModelFeatureRenderer.CrumblingOverlay breakProgress
    ) {
        // Populate base fields: blockPos, blockState, breakProgress, packed light, etc.
        BlockEntityRenderState.extractBase(be, rs, breakProgress);

        BlockState state = be.getBlockState();
        if (state == null) return;

        // Facing (your block uses HORIZONTAL_FACING)
        Direction facing = Direction.NORTH;
        if (state.hasProperty(ClassLockedChestBlock.FACING)) {
            facing = state.getValue(ClassLockedChestBlock.FACING);
        }
        rs.facing = facing;

        // Texture based on required class id
        rs.texture = textureFor(state);

        // Openness: use chest BE’s openness curve if available
        float open = 0.0F;
        try {
            open = be.getOpenNess(partialTick);
        } catch (Throwable ignored) {
            open = 0.0F;
        }

        // Smooth like vanilla
        open = 1.0F - open;
        open = 1.0F - open * open * open;

        rs.open = open;
    }

    @Override
    public void submit(State rs, PoseStack pose, SubmitNodeCollector collector, CameraRenderState cameraRenderState) {
        // Apply open to model
        this.model.setOpen(rs.open);

        // Render transform: center of block, rotate to facing
        pose.pushPose();
        pose.translate(0.5D, 0.5D, 0.5D);

        float yRot = switch (rs.facing) {
            case NORTH -> 180.0F;
            case SOUTH -> 0.0F;
            case WEST  -> 90.0F;
            case EAST  -> -90.0F;
            default    -> 0.0F;
        };
        pose.mulPose(com.mojang.math.Axis.YP.rotationDegrees(yRot));

        // Undo center to model space
        pose.translate(0.0D, -0.5D, 0.0D);

        // Use a direct texture RenderType (NOT the chest atlas path)
        RenderType rt = RenderType.entityCutout(rs.texture);

        // packedOverlay: most BE models just use NO_OVERLAY unless you have special overlay logic
        int packedOverlay = OverlayTexture.NO_OVERLAY;

        // 1.21.11+: submit ModelParts through the collector
        // Sprite = null because entityCutout(texture) is not an atlas sprite workflow
        collector.submitModelPart(this.model.base, pose, rt, rs.lightCoords, packedOverlay, null);
        collector.submitModelPart(this.model.lid,  pose, rt, rs.lightCoords, packedOverlay, null);
        collector.submitModelPart(this.model.knob, pose, rt, rs.lightCoords, packedOverlay, null);

        pose.popPose();
    }

    // ---------------------------------------------------------------------
    // Texture lookup
    // ---------------------------------------------------------------------
    private static ResourceLocation textureFor(BlockState state) {
        String cls = "none";
        if (state.getBlock() instanceof ClassLocked locked) {
            String req = locked.requiredClassId();
            if (req != null && !req.isBlank()) cls = req;
        }

        final String key = cls;
        return TEX_CACHE.computeIfAbsent(key, k ->
                ResourceLocation.fromNamespaceAndPath(
                        CosmicDungeonMod.MOD_ID,
                        "textures/entity/chest/" + k + "_chest.png"
                )
        );
    }

    private static ResourceLocation defaultTexture() {
        return ResourceLocation.fromNamespaceAndPath(
                CosmicDungeonMod.MOD_ID,
                "textures/entity/chest/none_chest.png"
        );
    }
}
