package net.goui.cosmicdungeon.client.model;

import net.goui.cosmicdungeon.CosmicDungeonMod;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;
import net.minecraft.resources.ResourceLocation;

/**
 * Class-locked chest model aligned to your Blockbench JSON:
 * groups / element names:
 *  - base
 *  - lid
 *  - knob
 *
 * Texture size: 64x64 (matches your JSON).
 */
public final class ClassLockedChestModel {

    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(
                    ResourceLocation.fromNamespaceAndPath(CosmicDungeonMod.MOD_ID, "class_locked_chest"),
                    "main"
            );

    public final ModelPart root;
    public final ModelPart base;
    public final ModelPart lid;
    public final ModelPart knob;

    public ClassLockedChestModel(ModelPart root) {
        this.root = root;
        this.base = root.getChild("base");
        this.lid  = root.getChild("lid");
        // knob is parented under lid (so it opens with the lid)
        this.knob = this.lid.getChild("knob");
    }

    /**
     * Geometry:
     * We keep a vanilla-ish chest volume, but the important part is:
     * - part names match Blockbench: base/lid/knob
     * - knob is a child of lid (matches your intent)
     *
     * If you want pixel-perfect match to your Blockbench element transforms,
     * we can do that too, but it requires mirroring Blockbench's coordinate/origin math
     * exactly. This is the "works + aligned names" version.
     */
    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        // BASE (your JSON: "base")
        root.addOrReplaceChild(
                "base",
                CubeListBuilder.create()
                        // You can adjust texOffs if you want to match your UV packing exactly.
                        // With your model JSON being an *item model*, UVs are coming from that JSON,
                        // but for BER geometry we use standard model UV offsets.
                        .texOffs(0, 19)
                        .addBox(-7.0F, -5.0F, -7.0F, 14.0F, 10.0F, 14.0F),
                // Sit on block (same as before)
                PartPose.offset(0.0F, 11.0F, 0.0F)
        );

        // LID (your JSON: "lid")
        PartDefinition lid = root.addOrReplaceChild(
                "lid",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        // lid box in local space; pivot at back-top edge
                        .addBox(-7.0F, -5.0F, -14.0F, 14.0F, 5.0F, 14.0F),
                // Pivot: y=6 (top of base), z=+7 (back edge)
                PartPose.offset(0.0F, 6.0F, 7.0F)
        );

        // KNOB (your JSON: "knob") — parented to lid so it rotates with it
        lid.addOrReplaceChild(
                "knob",
                CubeListBuilder.create()
                        .texOffs(0, 0)
                        .addBox(-1.0F, -2.0F, -1.0F, 2.0F, 4.0F, 1.0F),
                // Place it at the front of the lid
                PartPose.offset(0.0F, 2.0F, -14.0F)
        );

        return LayerDefinition.create(mesh, 64, 64);
    }

    /** Apply lid openness (0..1). */
    public void setOpen(float open) {
        this.lid.xRot = -(open * ((float) Math.PI / 2.0F));
        // knob is a child of lid, so it automatically follows lid rotation.
    }
}
