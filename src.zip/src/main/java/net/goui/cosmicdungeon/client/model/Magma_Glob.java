package net.goui.cosmicdungeon.client.model;

import net.goui.cosmicdungeon.CosmicDungeonMod;
import net.goui.cosmicdungeon.client.renderstate.MagmaGlobRenderState;
import net.goui.cosmicdungeon.client.anim.Magma_GlobAnimation;

import net.minecraft.client.animation.KeyframeAnimations;
import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;

public class Magma_Glob extends EntityModel<MagmaGlobRenderState> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(
                    ResourceLocation.fromNamespaceAndPath(CosmicDungeonMod.MOD_ID, "magma_glob"),
                    "main"
            );

    private final ModelPart root;
    private final ModelPart main;
    private final ModelPart eyes;
    private final ModelPart eye1;
    private final ModelPart eye2;
    private final ModelPart body;
    private final ModelPart base;

    public Magma_Glob(ModelPart root) {
        super(root);
        this.root = root;
        this.main = root.getChild("main");
        this.eyes = this.main.getChild("eyes");
        this.eye1 = this.eyes.getChild("eye1");
        this.eye2 = this.eyes.getChild("eye2");
        this.body = this.main.getChild("body");
        this.base = this.main.getChild("base");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition root = mesh.getRoot();

        PartDefinition main = root.addOrReplaceChild("main", CubeListBuilder.create(), PartPose.offset(2.0F, 8.0F, -7.0F));
        PartDefinition eyes = main.addOrReplaceChild("eyes", CubeListBuilder.create(), PartPose.ZERO);

        eyes.addOrReplaceChild("eye1",
                CubeListBuilder.create().texOffs(12, 28).addBox(-5.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                PartPose.ZERO
        );
        eyes.addOrReplaceChild("eye2",
                CubeListBuilder.create().texOffs(20, 28).addBox(-1.0F, 0.0F, -1.0F, 2.0F, 8.0F, 2.0F),
                PartPose.ZERO
        );

        main.addOrReplaceChild("body",
                CubeListBuilder.create()
                        .texOffs(18, 6).addBox(5.0F, 5.0F, -3.0F, 1.0F, 3.0F, 6.0F)
                        .texOffs(16, 4).addBox(4.0F, 4.0F, -4.0F, 1.0F, 5.0F, 8.0F)
                        .texOffs(14, 2).addBox(3.0F, 3.0F, -5.0F, 1.0F, 8.0F, 10.0F)
                        .texOffs(25, 2).addBox(-2.0F, 1.0F, -9.0F, 4.0F, 1.0F, 3.0F)
                        .texOffs(13, 1).addBox(-3.0F, 1.0F, -6.0F, 6.0F, 1.0F, 11.0F)
                        .texOffs(24, 5).addBox(-3.0F, 2.0F, -6.0F, 6.0F, 8.0F, 12.0F)
                        .texOffs(14, 2).addBox(-3.0F, 10.0F, -5.0F, 6.0F, 1.0F, 10.0F)
                        .texOffs(16, 4).addBox(-3.0F, 11.0F, -4.0F, 6.0F, 1.0F, 8.0F)
                        .texOffs(19, 6).addBox(-2.0F, 12.0F, -3.0F, 4.0F, 1.0F, 6.0F)
                        .texOffs(14, 2).addBox(-4.0F, 2.0F, -5.0F, 1.0F, 9.0F, 10.0F)
                        .texOffs(16, 4).addBox(-5.0F, 4.0F, -4.0F, 1.0F, 5.0F, 8.0F)
                        .texOffs(18, 6).addBox(-6.0F, 5.0F, -3.0F, 1.0F, 3.0F, 6.0F)
                        .texOffs(44, 30).addBox(2.0F, 2.0F, -10.0F, 1.0F, 6.0F, 2.0F)
                        .texOffs(42, 28).addBox(1.0F, 2.0F, -10.0F, 1.0F, 3.0F, 4.0F)
                        .texOffs(44, 30).addBox(1.0F, 5.0F, -10.0F, 1.0F, 3.0F, 2.0F)
                        .texOffs(26, 28).addBox(-1.0F, 2.0F, -10.0F, 2.0F, 3.0F, 4.0F)
                        .texOffs(28, 30).addBox(-1.0F, 5.0F, -10.0F, 2.0F, 3.0F, 2.0F)
                        .texOffs(34, 28).addBox(-2.0F, 2.0F, -10.0F, 1.0F, 3.0F, 4.0F)
                        .texOffs(36, 30).addBox(-2.0F, 5.0F, -10.0F, 1.0F, 3.0F, 2.0F)
                        .texOffs(36, 30).addBox(-3.0F, 2.0F, -10.0F, 1.0F, 6.0F, 2.0F),
                PartPose.offset(-2.0F, -8.0F, 9.0F)
        );

        main.addOrReplaceChild("base",
                CubeListBuilder.create().texOffs(14, 2).addBox(-3.0F, 0.0F, -9.0F, 6.0F, 1.0F, 13.0F),
                PartPose.offset(-2.0F, -8.0F, 9.0F)
        );

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public void setupAnim(MagmaGlobRenderState state) {
        // Reset pose each frame
        this.root.getAllParts().forEach(ModelPart::resetPose);

        // Walk
        if (state.walkAnimation != null && state.walkAnimation.isStarted()) {
            Magma_GlobAnimation.Magma_Glob_Walking.animate(this.root, state.ageInTicks);
        }

        // Attack
        if (state.attackAnimation != null && state.attackAnimation.isStarted()) {
            Magma_GlobAnimation.Magma_Glob_Attack.animate(this.root, state.ageInTicks);
        }
    }

}
