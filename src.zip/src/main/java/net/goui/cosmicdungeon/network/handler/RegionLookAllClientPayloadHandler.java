// file: src/main/java/net/goui/cosmicdungeon/network/handler/RegionLookAllClientPayloadHandler.java
package net.goui.cosmicdungeon.network.handler;

import net.goui.cosmicdungeon.network.payload.RegionLookAllPayload;
import net.goui.cosmicdungeon.region.client.RegionLookClient;
import net.neoforged.neoforge.network.handling.IPayloadContext;

public final class RegionLookAllClientPayloadHandler {
    private RegionLookAllClientPayloadHandler() {}

    public static void handle(final RegionLookAllPayload payload, final IPayloadContext ctx) {
        ctx.enqueueWork(() -> RegionLookClient.handleAll(payload));
    }
}
