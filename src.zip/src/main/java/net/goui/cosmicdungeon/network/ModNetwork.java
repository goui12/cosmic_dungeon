// file: src/main/java/net/goui/cosmicdungeon/network/ModNetwork.java
package net.goui.cosmicdungeon.network;

import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {
    private ModNetwork() {}

    // wired from CosmicDungeonMod constructor with modEventBus.addListener(ModNetwork::registerPayloadHandlers)
    public static void registerPayloadHandlers(final RegisterPayloadHandlersEvent event) {
        // "1" = your network protocol version
        final PayloadRegistrar registrar = event.registrar("1");

        // We only send this packet TO CLIENT
        registrar.playToClient(
                ShakeScreenPayload.TYPE,
                ShakeScreenPayload.STREAM_CODEC
        );
    }
}
