package net.goui.cosmicdungeon.block.custom;

public class ColoredBudBlock {
}
