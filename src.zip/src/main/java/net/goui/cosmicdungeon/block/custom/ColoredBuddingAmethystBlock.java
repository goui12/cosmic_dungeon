package net.goui.cosmicdungeon.block.custom;

import net.goui.cosmicdungeon.block.ModBlocks;
import net.goui.cosmicdungeon.common.color.AmethystColor;
import net.goui.cosmicdungeon.common.properties.ModProperties;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;

public class ColoredBuddingAmethystBlock extends Block {
    public static final DirectionProperty FACING = BlockStateProperties.FACING; // if needed
    // ... ctor + properties

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource rand) {
        AmethystColor color = state.getValue(ModProperties.COLOR);
        // Try each direction, similar to vanilla
        for (Direction dir : Direction.values()) {
            BlockPos target = pos.relative(dir);
            BlockState targetState = level.getBlockState(target);

            // empty -> place small bud
            if (targetState.isAir()) {
                level.setBlock(target, ModBlocks.COLORED_AMETHYST_BUD_SMALL.defaultBlockState()
                        .setValue(BlockStateProperties.FACING, dir)
                        .setValue(ModProperties.COLOR, color)
                        .setValue(BlockStateProperties.WATERLOGGED, false), 3);
                continue;
            }
            // small -> medium -> large -> cluster, preserving FACING & WATERLOGGED
            targetState = tryGrow(targetState, dir, color);
            if (targetState != null) level.setBlock(target, targetState, 3);
        }
    }

    private @Nullable BlockState tryGrow(BlockState s, Direction face, AmethystColor color) {
        if (s.is(CDBlockTags.SMALL_AMETHYST_BUD)) {
            return CDBlocks.AMETHYST_BUD_MEDIUM.defaultBlockState()
                    .setValue(BlockStateProperties.FACING, face)
                    .setValue(ModProperties.COLOR, color)
                    .setValue(BlockStateProperties.WATERLOGGED, s.getValue(BlockStateProperties.WATERLOGGED));
        }
        // …same pattern for medium->large, large->cluster
        return null;
    }

    @Override protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> b) {
        b.add(ModProperties.COLOR);
    }
}
