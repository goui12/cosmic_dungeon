package net.goui.cosmicdungeon.block.custom;

import it.unimi.dsi.fastutil.longs.LongArrayFIFOQueue;
import it.unimi.dsi.fastutil.longs.LongOpenHashSet;
import net.goui.cosmicdungeon.block.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

public class CosmicRiftTileBlock extends Block {

    private static final VoxelShape SHAPE = Block.box(0, 0, 0, 16, 1, 16);

    // Safety cap (64x64)
    private static final int MAX_BREAK_TILES = 64 * 64;

    // Prevent recursive destruction loops
    private static final ThreadLocal<Boolean> BREAKING_WHOLE =
            ThreadLocal.withInitial(() -> Boolean.FALSE);

    public CosmicRiftTileBlock(Properties props) {
        super(props);
    }

    @Override
    protected VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    protected VoxelShape getCollisionShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    /**
     * IMPORTANT: Your Minecraft Block class returns BlockState here (per your decompile),
     * so we MUST return BlockState too.
     */
    @Override
    public BlockState playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide()
                && level instanceof ServerLevel serverLevel
                && !Boolean.TRUE.equals(BREAKING_WHOLE.get())) {

            BREAKING_WHOLE.set(Boolean.TRUE);
            try {
                breakConnectedRift(serverLevel, pos, player);
            } finally {
                BREAKING_WHOLE.set(Boolean.FALSE);
            }
        }

        // Return whatever vanilla returns (usually the same state).
        return super.playerWillDestroy(level, pos, state, player);
    }

    private static void breakConnectedRift(ServerLevel level, BlockPos origin, Player player) {
        Block riftTile = ModBlocks.COSMIC_RIFT_TILE.get();
        int y = origin.getY();

        LongOpenHashSet visited = new LongOpenHashSet();
        LongArrayFIFOQueue queue = new LongArrayFIFOQueue();

        long start = origin.asLong();
        visited.add(start);
        queue.enqueue(start);

        while (!queue.isEmpty() && visited.size() <= MAX_BREAK_TILES) {
            long curKey = queue.dequeueLong();
            BlockPos cur = BlockPos.of(curKey);

            for (int i = 0; i < 4; i++) {
                BlockPos next = switch (i) {
                    case 0 -> cur.east();
                    case 1 -> cur.west();
                    case 2 -> cur.south();
                    default -> cur.north();
                };

                if (next.getY() != y) continue;

                long nk = next.asLong();
                if (visited.contains(nk)) continue;

                if (level.getBlockState(next).getBlock() != riftTile) continue;

                visited.add(nk);
                queue.enqueue(nk);
            }
        }

        // Destroy as one logical rift (drop only from the tile actually mined)
        for (long packed : visited) {
            BlockPos p = BlockPos.of(packed);
            boolean drop = p.equals(origin);
            level.destroyBlock(p, drop, player);
        }
    }
}
