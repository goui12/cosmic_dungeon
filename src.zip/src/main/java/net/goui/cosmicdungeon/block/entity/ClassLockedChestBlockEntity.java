// file: src/main/java/net/goui/cosmicdungeon/block/entity/ClassLockedChestBlockEntity.java
package net.goui.cosmicdungeon.block.entity;

import net.goui.cosmicdungeon.block.custom.ClassLocked;
import net.goui.cosmicdungeon.block.custom.ClassLockedChestBlock;
import net.goui.cosmicdungeon.playerclass.api.ClassNbtUtil;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ContainerUser;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.entity.ChestBlockEntity;

public class ClassLockedChestBlockEntity extends ChestBlockEntity {

    public ClassLockedChestBlockEntity(BlockPos pos, BlockState state) {
        // CRITICAL: bind to our BE type, not minecraft:chest
        super(ModBlockEntities.CLASS_LOCKED_CHEST.get(), pos, state);
    }

    @Override
    public boolean canOpen(Player player) {
        if (player instanceof ServerPlayer sp) {
            // Developers bypass class lock
            if (net.goui.cosmicdungeon.auth.AccessPolicy.isDeveloper(sp)) {
                return super.canOpen(player);
            }

            BlockState st = getBlockState();
            if (st != null && st.getBlock() instanceof ClassLocked locked) {
                String required = locked.requiredClassId();
                String have = ClassNbtUtil.getClassId(sp);
                if (required != null && !required.equals(have)) {
                    return false;
                }
            }
        }
        return super.canOpen(player);
    }


    /**
     * ChestBlockEntity's built-in open/close sound only runs if the block is a vanilla ChestBlock.
     * Since we are NOT extending ChestBlock, we play sounds here when the opener count transitions.
     */
    @Override
    public void startOpen(ContainerUser user) {
        Level level = this.getLevel();
        if (level == null || level.isClientSide()) {
            super.startOpen(user);
            return;
        }

        int before = ChestBlockEntity.getOpenCount(level, this.getBlockPos());
        super.startOpen(user);
        int after = ChestBlockEntity.getOpenCount(level, this.getBlockPos());

        if (before == 0 && after > 0) {
            BlockState st = this.getBlockState();
            if (st.getBlock() instanceof ClassLockedChestBlock chest) {
                ClassLockedChestBlock.playChestSound(level, this.getBlockPos(), chest.getOpenSound());
            }
        }
    }

    @Override
    public void stopOpen(ContainerUser user) {
        Level level = this.getLevel();
        if (level == null || level.isClientSide()) {
            super.stopOpen(user);
            return;
        }

        int before = ChestBlockEntity.getOpenCount(level, this.getBlockPos());
        super.stopOpen(user);
        int after = ChestBlockEntity.getOpenCount(level, this.getBlockPos());

        if (before > 0 && after == 0) {
            BlockState st = this.getBlockState();
            if (st.getBlock() instanceof ClassLockedChestBlock chest) {
                ClassLockedChestBlock.playChestSound(level, this.getBlockPos(), chest.getCloseSound());
            }
        }
    }
}
