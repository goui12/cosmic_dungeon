package net.goui.cosmicdungeon.block.entity;

import net.goui.cosmicdungeon.CosmicDungeonMod;
import net.goui.cosmicdungeon.block.ModBlocks;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModBlockEntities {
    private ModBlockEntities() {}

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(Registries.BLOCK_ENTITY_TYPE, CosmicDungeonMod.MOD_ID);

    // 1.21.6–1.21.8: use the public constructor (factory, onlyOpsLoadComponents, blocks...)
    public static final DeferredHolder<BlockEntityType<?>, BlockEntityType<CommandDoorBlockEntity>> COMMAND_DOOR =
            BLOCK_ENTITIES.register("command_door", () ->
                    new BlockEntityType<>(
                            CommandDoorBlockEntity::new,
                            false,                           // only allow OPs to load BE components from NBT? (false = no restriction)
                            ModBlocks.COMMAND_DOOR.get()     // blocks that host this BE
                    )
            );

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
    }
}
