package net.goui.cosmicdungeon.block.door;

import net.goui.cosmicdungeon.block.entity.CommandDoorBlockEntity;
import net.goui.cosmicdungeon.block.entity.ModBlockEntities;
import net.goui.cosmicdungeon.component.ModDataComponents;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import org.jetbrains.annotations.Nullable;

public class CommandDoorBlock extends DoorBlock implements EntityBlock {

    public CommandDoorBlock(BlockSetType setType, Properties props) {
        super(setType, props
                .noOcclusion()
                .strength(5.0F)
                .sound(SoundType.METAL)
        );
        // DoorBlock already registers FACING, OPEN, HINGE, POWERED, HALF.
        // Default state is handled by DoorBlock too; you don't need to re-register it here.
    }

    // --------- Placement: copy close-limit from the item to the BE ---------
    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (level.isClientSide) return;

        BlockPos base = state.getValue(HALF) == DoubleBlockHalf.LOWER ? pos : pos.below();
        BlockEntity be = level.getBlockEntity(base);
        if (be instanceof CommandDoorBlockEntity cbe) {
            int limit = stack.getOrDefault(ModDataComponents.DOOR_CLOSE_LIMIT.get(), 1);
            cbe.setCloseLimit(limit);
            cbe.resetOpenSession();
            cbe.setLocked(false);
            cbe.setLastPowered(false);
        }
    }

    // No override of neighborChanged — your ticker handles logic.

    // --------- Block Entity / Ticker ---------
    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        if (state.getValue(HALF) == DoubleBlockHalf.UPPER) return null; // only lower creates BE
        return ModBlockEntities.COMMAND_DOOR.get().create(pos, state);
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        if (level.isClientSide) return null;
        return type == ModBlockEntities.COMMAND_DOOR.get()
                ? (lvl, p, st, be) -> CommandDoorBlockEntity.serverTick(lvl, p, st, (CommandDoorBlockEntity) be)
                : null;
    }

    // --------- Helpers ---------
    public static void setOpenBoth(ServerLevel level, BlockPos base, BlockState baseState, boolean open) {
        BlockState newBase = baseState.setValue(OPEN, open);
        level.setBlock(base, newBase, 10);
        BlockPos topPos = base.above();
        BlockState topState = level.getBlockState(topPos);
        if (topState.getBlock() instanceof CommandDoorBlock && topState.getValue(HALF) == DoubleBlockHalf.UPPER) {
            level.setBlock(topPos, topState.setValue(OPEN, open), 10);
        }
        level.levelEvent(null, open ? 1005 : 1011, base, 0); // door open/close sound
    }
}
