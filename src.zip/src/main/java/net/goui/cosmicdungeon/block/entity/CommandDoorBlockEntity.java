package net.goui.cosmicdungeon.block.entity;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

import net.goui.cosmicdungeon.block.door.CommandDoorBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.storage.ValueInput;
import net.minecraft.world.level.storage.ValueOutput;
import net.minecraft.world.phys.AABB;

public class CommandDoorBlockEntity extends BlockEntity {
    /** Configured from the placed item; default 1. */
    private int closeLimit = 1;

    /** Tracks unique players this open session. */
    private final Set<UUID> countedThisOpen = new HashSet<>();

    /** If true, the door will not re-open until a new rising-edge redstone pulse. */
    private boolean lockedUntilRisingEdge = false;

    /** Rising-edge detector state. */
    private boolean lastPowered = false;

    public CommandDoorBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.COMMAND_DOOR.get(), pos, state);
    }

    // --------- Accessors ---------
    public void setCloseLimit(int limit) { this.closeLimit = Math.max(1, limit); setChanged(); }
    public int getCloseLimit() { return closeLimit; }

    public boolean isLocked() { return lockedUntilRisingEdge; }
    public void setLocked(boolean locked) { this.lockedUntilRisingEdge = locked; setChanged(); }

    public boolean getLastPowered() { return lastPowered; }
    public void setLastPowered(boolean powered) { this.lastPowered = powered; setChanged(); }

    public void resetOpenSession() { this.countedThisOpen.clear(); setChanged(); }

    // --------- Ticker (drives all redstone + counting logic) ---------
    public static void serverTick(Level level, BlockPos pos, BlockState state, CommandDoorBlockEntity be) {
        if (!(level instanceof ServerLevel server)) return;

        // Only operate from the LOWER half to avoid double counting.
        if (state.getValue(CommandDoorBlock.HALF) == DoubleBlockHalf.UPPER) return;

        BlockPos base = pos;

        boolean poweredNow = level.hasNeighborSignal(base) || level.hasNeighborSignal(base.above());
        boolean last = be.getLastPowered();

        // Handle edges
        if (poweredNow != last) {
            be.setLastPowered(poweredNow);

            if (poweredNow) { // Rising edge: unlock, reset, open, set POWERED
                be.setLocked(false);
                be.resetOpenSession();

                BlockState cur = level.getBlockState(base);
                if (!cur.getValue(CommandDoorBlock.OPEN)) {
                    CommandDoorBlock.setOpenBoth(server, base, cur, true);
                }
                level.setBlock(base, level.getBlockState(base).setValue(CommandDoorBlock.POWERED, true), 2);
            } else { // Falling edge: close, set POWERED false
                BlockState cur = level.getBlockState(base);
                if (cur.getValue(CommandDoorBlock.OPEN)) {
                    CommandDoorBlock.setOpenBoth(server, base, cur, false);
                }
                level.setBlock(base, level.getBlockState(base).setValue(CommandDoorBlock.POWERED, false), 2);
            }
        }

        // If powered and locked, enforce closed.
        if (poweredNow && be.isLocked()) {
            BlockState cur = level.getBlockState(base);
            if (cur.getValue(CommandDoorBlock.OPEN)) {
                CommandDoorBlock.setOpenBoth(server, base, cur, false);
            }
            return;
        }

        // If the door is open and not locked, count unique players passing through.
        BlockState cur = level.getBlockState(base);
        if (!cur.getValue(CommandDoorBlock.OPEN)) return;

        AABB box = new AABB(
                base.getX(), base.getY(), base.getZ(),
                base.getX() + 1, base.getY() + 2, base.getZ() + 1
        ).inflate(0.0625D);

        for (ServerPlayer p : server.getEntitiesOfClass(ServerPlayer.class, box, pl -> !pl.isSpectator())) {
            UUID id = p.getUUID();
            if (be.countedThisOpen.add(id)) {
                if (be.countedThisOpen.size() >= be.closeLimit) {
                    // Reached threshold: close and lock until next rising edge.
                    CommandDoorBlock.setOpenBoth(server, base, cur, false);
                    be.setLocked(true);
                    be.setChanged();
                    break;
                }
            }
        }
    }

    // --------- Persistence (ValueOutput / ValueInput) ---------
    @Override
    protected void saveAdditional(ValueOutput output) {
        super.saveAdditional(output);
        output.putInt("closeLimit", this.closeLimit);
        output.putBoolean("locked", this.lockedUntilRisingEdge);
        output.putBoolean("lastPowered", this.lastPowered);
    }

    @Override
    protected void loadAdditional(ValueInput input) {
        super.loadAdditional(input);
        this.closeLimit = Math.max(1, input.getIntOr("closeLimit", 1));
        this.lockedUntilRisingEdge = input.getBooleanOr("locked", false);
        this.lastPowered = input.getBooleanOr("lastPowered", false);
    }
}