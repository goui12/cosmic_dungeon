// file: src/main/java/net/goui/cosmicdungeon/datagen/ModItemDefinitionsProvider.java
package net.goui.cosmicdungeon.datagen;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import net.goui.cosmicdungeon.CosmicDungeonMod;
import net.goui.cosmicdungeon.block.ModBlocks;
import net.minecraft.data.CachedOutput;
import net.minecraft.data.DataProvider;
import net.minecraft.data.PackOutput;
import net.minecraft.resources.ResourceLocation;

import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * 1.21+ Item Definitions provider.
 *
 * We generate assets/<modid>/items/<item>.json for the 8 class-locked chest ITEMS.
 *
 * IMPORTANT:
 * - NO minecraft:special
 * - NO chest model type
 * - NO "type" field at all
 * - The definition only points at our normal item model: <modid>:item/<id>
 *
 * This guarantees we do NOT trigger the chest atlas pipeline.
 */
public final class ModItemDefinitionsProvider implements DataProvider {

    @SuppressWarnings("unused")
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private final PackOutput packOutput;

    public ModItemDefinitionsProvider(PackOutput packOutput) {
        this.packOutput = packOutput;
    }

    @Override
    public String getName() {
        return "Cosmic Dungeon Item Definitions (1.21+ items/*.json)";
    }

    @Override
    public CompletableFuture<?> run(CachedOutput cache) {
        // 1.21+ item definitions: assets/<modid>/items/<item>.json
        Path outRoot = this.packOutput.getOutputFolder(PackOutput.Target.RESOURCE_PACK)
                .resolve(CosmicDungeonMod.MOD_ID)
                .resolve("items");

        // IMPORTANT: these must be ITEM ids (BlockItem IDs), not block ids.
        List<ResourceLocation> chestItemIds = List.of(
                ModBlocks.BOGATYR_CHEST_ITEM.getId(),
                ModBlocks.DEADEYE_CHEST_ITEM.getId(),
                ModBlocks.DRAGOON_CHEST_ITEM.getId(),
                ModBlocks.JUDICATOR_CHEST_ITEM.getId(),
                ModBlocks.METALMANCER_CHEST_ITEM.getId(),
                ModBlocks.PYROCLAST_CHEST_ITEM.getId(),
                ModBlocks.THEURGIST_CHEST_ITEM.getId(),
                ModBlocks.VENEFEX_CHEST_ITEM.getId()
        );

        CompletableFuture<?>[] futures = new CompletableFuture<?>[chestItemIds.size()];

        for (int i = 0; i < chestItemIds.size(); i++) {
            ResourceLocation id = chestItemIds.get(i);

            // Minimal definition: just point at our normal item model.
            // No "type". No minecraft references. No special pipeline.
            JsonObject root = new JsonObject();
            root.addProperty("model", ResourceLocation.fromNamespaceAndPath(
                    CosmicDungeonMod.MOD_ID,
                    "item/" + id.getPath()
            ).toString());

            Path file = outRoot.resolve(id.getPath() + ".json");
            futures[i] = DataProvider.saveStable(cache, root, file);
        }

        return CompletableFuture.allOf(futures);
    }
}
