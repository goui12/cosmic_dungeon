package net.goui.cosmicdungeon.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.goui.cosmicdungeon.component.ModDataComponents;
import net.goui.cosmicdungeon.item.custom.CommandDoorItem;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;

public final class DoorCommand {
    private DoorCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        LiteralArgumentBuilder<CommandSourceStack> root = Commands.literal("door")
                .requires(src -> src.hasPermission(2)) // OPs only
                .then(Commands.literal("close_pass_limit")
                        .then(Commands.argument("number", IntegerArgumentType.integer(1, 1024))
                                .executes(DoorCommand::setCloseLimit)));

        dispatcher.register(root);
    }

    private static int setCloseLimit(CommandContext<CommandSourceStack> ctx) {
        CommandSourceStack src = ctx.getSource();
        int n = IntegerArgumentType.getInteger(ctx, "number");

        Player p = src.getEntity() instanceof Player pl ? pl : null;
        if (p == null) {
            src.sendFailure(Component.literal("Run this in-game while holding the Command Door item."));
            return 0;
        }

        ItemStack inHand = p.getMainHandItem();
        if (!(inHand.getItem() instanceof CommandDoorItem)) {
            src.sendFailure(Component.literal("Hold a Command Door item in your main hand."));
            return 0;
        }

        inHand.set(ModDataComponents.DOOR_CLOSE_LIMIT.get(), n);
        src.sendSuccess(() -> Component.literal("Command Door close_pass_limit set to " + n), true);
        return 1;
    }
}
