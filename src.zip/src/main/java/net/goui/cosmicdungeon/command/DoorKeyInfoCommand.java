package net.goui.cosmicdungeon.command;

import com.mojang.brigadier.CommandDispatcher;
import net.goui.cosmicdungeon.component.ModDataComponents;
import net.goui.cosmicdungeon.door.DoorLockData;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.item.ItemStack;

import java.util.Optional;
import java.util.UUID;

public final class DoorKeyInfoCommand {
    private DoorKeyInfoCommand() {}

    public static void register(CommandDispatcher<CommandSourceStack> dispatcher) {
        dispatcher.register(
                Commands.literal("door").then(
                        Commands.literal("key").then(
                                Commands.literal("info")
                                        .executes(ctx -> {
                                            ServerPlayer p = ctx.getSource().getPlayerOrException();
                                            ItemStack stack = findKeyInHands(p);
                                            if (stack.isEmpty()) {
                                                ctx.getSource().sendFailure(Component.literal("Hold a Door Key in your hand."));
                                                return 0;
                                            }
                                            UUID id = stack.getOrDefault(ModDataComponents.DOOR_LOCK_ID.get(), null);
                                            if (id == null) {
                                                ctx.getSource().sendFailure(Component.literal("This key is unbound."));
                                                return 0;
                                            }
                                            ctx.getSource().sendSuccess(() -> Component.literal("Key Lock ID: " + id), false);

                                            DoorLockData data = DoorLockData.get(p.level());
                                            Optional<DoorLockData.DoorRef> ref = data.findByLockId(id);
                                            ref.ifPresent(r -> {
                                                ctx.getSource().sendSuccess(() -> Component.literal("Door: " + r.lowerPos().toShortString()
                                                        + " in " + r.dimension()), false);
                                            });

                                            return 1;
                                        })
                        )
                )
        );
    }

    private static ItemStack findKeyInHands(ServerPlayer p) {
        ItemStack main = p.getMainHandItem();
        if (main.get(ModDataComponents.DOOR_LOCK_ID.get()) != null) return main;
        ItemStack off = p.getOffhandItem();
        if (off.get(ModDataComponents.DOOR_LOCK_ID.get()) != null) return off;
        return ItemStack.EMPTY;
    }
}
