package net.goui.cosmicdungeon.item.custom;

import java.util.function.Consumer;

import net.goui.cosmicdungeon.component.ModDataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.TooltipDisplay;
import net.minecraft.world.level.block.Block;

public class CommandDoorItem extends BlockItem {
    public CommandDoorItem(Block block, Properties props) {
        super(block, props);
    }

    @Override
    public void appendHoverText(ItemStack stack, TooltipContext ctx, TooltipDisplay display,
                                Consumer<Component> tooltip, TooltipFlag flag) {
        int n = stack.getOrDefault(ModDataComponents.DOOR_CLOSE_LIMIT.get(), 1);
        tooltip.accept(Component.translatable("tooltip.cosmicdungeon.command_door", n, n));
    }

}
